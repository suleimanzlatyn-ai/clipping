import type { Project, ProjectSummary } from "./types";

const DB_NAME = "zlatyn";
const DB_VERSION = 1;

const memProjects = new Map<string, Project>();
const memFiles = new Map<string, Blob>();

function openDb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (typeof indexedDB === "undefined") {
      resolve(null);
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("projects")) {
        db.createObjectStore("projects", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("files")) {
        db.createObjectStore("files");
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(null);
  });
}

function reqToPromise<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Storage request failed"));
  });
}

export async function saveProject(project: Project): Promise<void> {
  memProjects.set(project.id, project);
  const db = await openDb();
  if (!db) return;
  try {
    await reqToPromise(db.transaction("projects", "readwrite").objectStore("projects").put(project));
  } catch {
    /* memory still holds it */
  } finally {
    db.close();
  }
}

export async function getProject(id: string): Promise<Project | null> {
  const db = await openDb();
  if (db) {
    try {
      const value = (await reqToPromise(
        db.transaction("projects").objectStore("projects").get(id),
      )) as Project | undefined;
      if (value) {
        memProjects.set(id, value);
        return value;
      }
    } catch {
      /* fall through */
    } finally {
      db.close();
    }
  }
  return memProjects.get(id) ?? null;
}

export async function listProjects(): Promise<ProjectSummary[]> {
  const db = await openDb();
  let rows: Project[] = [...memProjects.values()];
  if (db) {
    try {
      const stored = (await reqToPromise(
        db.transaction("projects").objectStore("projects").getAll(),
      )) as Project[];
      const map = new Map(rows.map((p) => [p.id, p]));
      for (const p of stored) map.set(p.id, p);
      rows = [...map.values()];
    } catch {
      /* memory list */
    } finally {
      db.close();
    }
  }
  return rows
    .map((p) => ({
      id: p.id,
      name: p.name,
      createdAt: p.createdAt,
      duration: p.duration,
      status: p.status,
      clipCount: p.clips.length,
      sourceKind: p.sourceKind,
      thumbnail: p.youtubeThumb ?? p.clips.find((c) => c.thumbnail)?.thumbnail,
    }))
    .sort((a, b) => b.createdAt - a.createdAt);
}

export async function deleteProject(id: string): Promise<void> {
  memProjects.delete(id);
  memFiles.delete(id);
  const db = await openDb();
  if (!db) return;
  try {
    const tx = db.transaction(["projects", "files"], "readwrite");
    tx.objectStore("projects").delete(id);
    tx.objectStore("files").delete(id);
    await new Promise<void>((resolve) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } finally {
    db.close();
  }
}

export async function saveFile(id: string, file: Blob): Promise<void> {
  memFiles.set(id, file);
  const db = await openDb();
  if (!db) return;
  try {
    await reqToPromise(db.transaction("files", "readwrite").objectStore("files").put(file, id));
  } catch {
    /* keep the in-memory copy — quota must not block clipping */
  } finally {
    db.close();
  }
}

export async function getFile(id: string): Promise<Blob | null> {
  if (memFiles.has(id)) return memFiles.get(id) ?? null;
  const db = await openDb();
  if (!db) return null;
  try {
    const value = (await reqToPromise(db.transaction("files").objectStore("files").get(id))) as
      | Blob
      | undefined;
    if (value) memFiles.set(id, value);
    return value ?? null;
  } catch {
    return null;
  } finally {
    db.close();
  }
}
