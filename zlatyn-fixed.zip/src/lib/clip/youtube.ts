import { createServerFn } from "@tanstack/react-start";
import type { Word } from "./types";

export function parseYoutubeId(input: string): string | null {
  const raw = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(raw)) return raw;
  try {
    const url = new URL(raw);
    const host = url.hostname.replace(/^www\./, "");
    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return id && /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
    }
    const v = url.searchParams.get("v");
    if (v && /^[a-zA-Z0-9_-]{11}$/.test(v)) return v;
    const m = url.pathname.match(/\/(shorts|embed|live)\/([a-zA-Z0-9_-]{11})/);
    return m?.[2] ?? null;
  } catch {
    return null;
  }
}

function extractObject(html: string, marker: string): Record<string, unknown> | null {
  const i = html.indexOf(marker);
  if (i < 0) return null;
  const start = html.indexOf("{", i);
  if (start < 0) return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let p = start; p < html.length; p++) {
    const ch = html[p]!;
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === "{") depth += 1;
    else if (ch === "}") {
      depth -= 1;
      if (depth === 0) {
        try {
          return JSON.parse(html.slice(start, p + 1)) as Record<string, unknown>;
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

type CaptionTrack = { baseUrl?: string; languageCode?: string; kind?: string };

function tracksFromPlayer(player: Record<string, unknown>): CaptionTrack[] {
  const captions = player.captions as
    | { playerCaptionsTracklistRenderer?: { captionTracks?: CaptionTrack[] } }
    | undefined;
  return captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
}

function pickTrack(tracks: CaptionTrack[]): CaptionTrack | null {
  if (!tracks.length) return null;
  const scored = [...tracks].sort((a, b) => {
    const rank = (t: CaptionTrack) => {
      const lang = (t.languageCode ?? "").toLowerCase();
      let n = 0;
      if (lang === "en" || lang.startsWith("en-")) n += 4;
      if (t.kind !== "asr") n += 2;
      return n;
    };
    return rank(b) - rank(a);
  });
  return scored[0] ?? null;
}

function wordsFromJson3(data: {
  events?: { tStartMs?: number; dDurationMs?: number; segs?: { utf8?: string }[] }[];
}): Word[] {
  const words: Word[] = [];
  for (const ev of data.events ?? []) {
    const startMs = ev.tStartMs ?? 0;
    const dur = ev.dDurationMs ?? 0;
    const text = (ev.segs ?? [])
      .map((s) => s.utf8 ?? "")
      .join("")
      .replace(/\n/g, " ")
      .trim();
    if (!text) continue;
    const tokens = text.split(/\s+/).filter(Boolean);
    const slice = tokens.length ? dur / tokens.length : dur;
    tokens.forEach((token, i) => {
      const start = (startMs + i * slice) / 1000;
      words.push({ text: token, start, end: start + Math.max(0.08, slice / 1000) });
    });
  }
  return words;
}

async function fetchCaptionWords(baseUrl: string): Promise<Word[]> {
  const url = new URL(baseUrl.replace(/&fmt=\w+/g, ""));
  url.searchParams.set("fmt", "json3");
  const res = await fetch(url.toString(), {
    headers: { "Accept-Language": "en-US,en;q=0.9" },
  });
  if (!res.ok) return [];
  const json = (await res.json()) as Parameters<typeof wordsFromJson3>[0];
  return wordsFromJson3(json);
}

const WATCH_HEADERS = {
  "Accept-Language": "en-US,en;q=0.9",
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
};

export const fetchYoutubeSource = createServerFn({ method: "POST" })
  .validator((input: { url: string }) => input)
  .handler(
    async ({
      data,
    }): Promise<
      | {
          ok: true;
          videoId: string;
          title: string;
          thumbnail: string;
          author: string;
          duration: number;
          transcript: string;
          words: Word[];
        }
      | { ok: false; error: string }
    > => {
      const videoId = parseYoutubeId(data.url);
      if (!videoId) return { ok: false, error: "That is not a YouTube link" };

      let title = "YouTube video";
      let thumbnail = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
      let author = "";
      let duration = 0;
      let words: Word[] = [];

      try {
        const oembedRes = await fetch(
          `https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}&format=json`,
        );
        if (oembedRes.ok) {
          const oembed = (await oembedRes.json()) as {
            title?: string;
            thumbnail_url?: string;
            author_name?: string;
          };
          title = oembed.title ?? title;
          thumbnail = oembed.thumbnail_url ?? thumbnail;
          author = oembed.author_name ?? "";
        }
      } catch {
        /* keep defaults */
      }

      try {
        const watch = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
          headers: WATCH_HEADERS,
        });
        const html = await watch.text();
        const player = extractObject(html, "ytInitialPlayerResponse");
        if (player) {
          const details = player.videoDetails as
            | { title?: string; lengthSeconds?: string; author?: string; thumbnail?: { thumbnails?: { url: string }[] } }
            | undefined;
          if (details?.title) title = details.title;
          if (details?.author) author = details.author;
          if (details?.lengthSeconds) duration = Number(details.lengthSeconds) || 0;
          const lastThumb = details?.thumbnail?.thumbnails?.at(-1)?.url;
          if (lastThumb) thumbnail = lastThumb;
          const track = pickTrack(tracksFromPlayer(player));
          if (track?.baseUrl) words = await fetchCaptionWords(track.baseUrl);
        }
      } catch {
        /* fall through */
      }

      if (!words.length) {
        try {
          const timed = await fetch(
            `https://www.youtube.com/api/timedtext?v=${videoId}&lang=en&fmt=json3`,
            { headers: WATCH_HEADERS },
          );
          if (timed.ok) {
            const json = (await timed.json()) as Parameters<typeof wordsFromJson3>[0];
            words = wordsFromJson3(json);
          }
        } catch {
          /* none */
        }
      }

      const transcript = words.map((w) => w.text).join(" ");
      if (!transcript) {
        return {
          ok: false,
          error: "No captions on this video. Drop the file and Zlatyn will transcribe it.",
        };
      }
      if (!duration && words.length) duration = words.at(-1)!.end;

      return { ok: true, videoId, title, thumbnail, author, duration, transcript, words };
    },
  );
