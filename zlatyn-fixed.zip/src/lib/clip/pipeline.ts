import { generateClips } from "./ai";
import { extractAudioChunks, grabFrame, readVideoDuration } from "./audio";
import { stripFillers, wordsFromPlainTranscript } from "./captions";
import { heuristicClips } from "./heuristic";
import { getFile, getProject, saveFile, saveProject } from "./idb";
import type { Project, Word } from "./types";

type SttResponse = {
  ok: boolean;
  error?: string;
  text?: string;
  language?: string;
  duration?: number;
  words?: Word[];
};

async function transcribe(blob: Blob, filename: string): Promise<SttResponse> {
  const form = new FormData();
  form.append("file", blob, filename);
  const res = await fetch("/api/stt", { method: "POST", body: form });
  return (await res.json()) as SttResponse;
}

const STT_CONCURRENCY = 3;
const inflight = new Map<string, Promise<Project>>();

async function transcribeWithRetry(blob: Blob, filename: string): Promise<SttResponse> {
  let last: SttResponse = { ok: false, error: "Transcription failed" };
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      last = await transcribe(blob, filename);
      if (last.ok && last.text) return last;
      // 4xx (bad audio, too large, no key) will not improve on retry.
      if (last.error && /too large|No audio|not available/i.test(last.error)) return last;
    } catch {
      last = { ok: false, error: "Network error while transcribing" };
    }
  }
  return last;
}

/**
 * One pipeline per project at a time. A remount (back/forward, StrictMode, a second tab
 * event) used to start a second run and double-bill speech-to-text.
 */
export function runPipeline(
  id: string,
  onChange: (project: Project) => void,
): Promise<Project> {
  const running = inflight.get(id);
  if (running) return running;
  const job = runPipelineInner(id, onChange).finally(() => inflight.delete(id));
  inflight.set(id, job);
  return job;
}

async function runPipelineInner(
  id: string,
  onChange: (project: Project) => void,
): Promise<Project> {
  const existing = await getProject(id);
  if (!existing) throw new Error("Project not found");
  if (existing.status === "ready" && existing.clips.length) return existing;

  const patch = async (partial: Partial<Project>) => {
    const current = (await getProject(id)) ?? existing;
    const next = { ...current, ...partial };
    await saveProject(next);
    onChange(next);
    return next;
  };

  let project = await patch({
    status: "transcribing",
    progress: 8,
    progressLabel: projectLabel(existing),
    error: undefined,
  });

  const file = await getFile(id);
  let words = project.words;
  let transcript = project.transcript;

  if (!transcript && file) {
    try {
      const audio = await extractAudioChunks(file);
      project = await patch({
        progress: 20,
        progressLabel: "Transcribing speech",
        truncated: audio.truncated,
        duration: project.duration || audio.duration,
      });
      const total = audio.chunks.length;
      let done = 0;
      const results: SttResponse[] = new Array(total);
      let next = 0;
      let failure: string | null = null;
      const worker = async () => {
        while (failure === null) {
          const i = next++;
          if (i >= total) return;
          const chunk = audio.chunks[i]!;
          const stt = await transcribeWithRetry(chunk.blob, chunk.filename);
          if (!stt.ok || !stt.text) {
            // A silent chunk is fine; a failed request is not.
            if (stt.ok) {
              results[i] = { ok: true, text: "", words: [] };
            } else {
              failure = stt.error || "Transcription failed";
              return;
            }
          } else {
            results[i] = stt;
          }
          done += 1;
          void patch({
            progress: 20 + Math.round((done / total) * 40),
            progressLabel: `Transcribing speech (${done}/${total})`,
          });
        }
      };
      await Promise.all(
        Array.from({ length: Math.min(STT_CONCURRENCY, total) }, () => worker()),
      );
      if (failure !== null) throw new Error(failure);

      const collected: Word[] = [];
      const texts: string[] = [];
      results.forEach((stt, i) => {
        if (!stt?.text) return;
        texts.push(stt.text);
        const offset = audio.chunks[i]!.offset;
        for (const w of stt.words ?? []) {
          collected.push({ ...w, start: w.start + offset, end: w.end + offset });
        }
      });
      if (!texts.length) throw new Error("No speech was detected in this file.");
      transcript = texts.join(" ");
      words = collected.length
        ? collected
        : wordsFromPlainTranscript(transcript, project.duration || audio.duration);
      project = await patch({
        words,
        transcript,
        progress: 62,
        progressLabel: "Hunting the hook",
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not transcribe this video";
      return patch({ status: "error", error: message, progress: 0, progressLabel: "Needs a transcript" });
    }
  } else {
    if (!words.length && transcript) {
      words = wordsFromPlainTranscript(transcript, project.duration || 60);
      project = await patch({ words });
    }
    project = await patch({
      status: "clipping",
      progress: 62,
      progressLabel: "Hunting the hook",
    });
  }

  const cleaned = project.settings.removeFillers ? stripFillers(words) : words;
  project = await patch({
    status: "clipping",
    progress: 70,
    progressLabel: "Scoring moments",
    words: cleaned,
    transcript,
  });

  const result = await generateClips({
    data: {
      words: cleaned,
      duration: project.duration,
      settings: project.settings,
      transcript,
    },
  });

  let clips = result.clips;
  if (!clips.length) clips = heuristicClips(cleaned, project.settings);

  if (file) {
    project = await patch({ progress: 88, progressLabel: "Grabbing stills", clips });
    const thumbs = await Promise.all(
      clips.map(async (clip) => ({
        id: clip.id,
        thumbnail: await grabFrame(file, clip.start + Math.min(1.2, (clip.end - clip.start) * 0.25)),
      })),
    );
    const map = new Map(thumbs.map((t) => [t.id, t.thumbnail]));
    clips = clips.map((c) => ({ ...c, thumbnail: map.get(c.id) ?? c.thumbnail }));
  } else if (project.youtubeThumb) {
    clips = clips.map((c) => ({ ...c, thumbnail: c.thumbnail ?? project.youtubeThumb }));
  }

  return patch({
    status: "ready",
    progress: 100,
    progressLabel: "Ready",
    clips,
    error: result.ok ? undefined : result.error,
  });
}

function projectLabel(project: Project) {
  if (project.sourceKind === "youtube") return "Reading captions";
  return "Reading the soundtrack";
}

export async function createUploadProject(
  file: File,
  settings: Project["settings"],
  transcript = "",
): Promise<Project> {
  const duration = await readVideoDuration(file).catch(() => 0);
  const project: Project = {
    id: crypto.randomUUID(),
    name: file.name.replace(/\.[^.]+$/, "") || "Untitled video",
    createdAt: Date.now(),
    duration,
    status: "queued",
    progress: 4,
    progressLabel: "Queued",
    settings,
    words: transcript ? wordsFromPlainTranscript(transcript, duration || 60) : [],
    transcript,
    clips: [],
    sourceKind: "upload",
    sourceName: file.name,
  };
  await saveFile(project.id, file);
  await saveProject(project);
  return project;
}

export async function createYoutubeProject(
  source: {
    videoId: string;
    title: string;
    thumbnail: string;
    duration: number;
    transcript: string;
    words: Word[];
  },
  settings: Project["settings"],
  file?: File | null,
): Promise<Project> {
  const project: Project = {
    id: crypto.randomUUID(),
    name: source.title,
    createdAt: Date.now(),
    duration: source.duration,
    status: "queued",
    progress: 12,
    progressLabel: "Hunting the hook",
    settings,
    words: source.words,
    transcript: source.transcript,
    clips: [],
    sourceKind: "youtube",
    sourceName: source.videoId,
    youtubeId: source.videoId,
    youtubeThumb: source.thumbnail,
  };
  // Keeping the real file next to the link gives local preview, still frames and export.
  if (file) await saveFile(project.id, file);
  await saveProject(project);
  return project;
}

export async function attachFileToProject(id: string, file: File): Promise<Project | null> {
  const project = await getProject(id);
  if (!project) return null;
  await saveFile(id, file);
  const duration = await readVideoDuration(file).catch(() => project.duration);
  const next = { ...project, duration: duration || project.duration };
  await saveProject(next);
  return next;
}