import { MAX_DECODE_BYTES, MAX_TRANSCRIBE_SECONDS, STT_CHUNK_SECONDS } from "./types";

function writeString(view: DataView, offset: number, str: string) {
  for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
}

export function encodeWav(buffer: AudioBuffer): Blob {
  const channels = 1;
  const rate = buffer.sampleRate;
  const data = buffer.getChannelData(0);
  const bytes = new ArrayBuffer(44 + data.length * 2);
  const view = new DataView(bytes);
  writeString(view, 0, "RIFF");
  view.setUint32(4, 36 + data.length * 2, true);
  writeString(view, 8, "WAVE");
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, rate, true);
  view.setUint32(28, rate * channels * 2, true);
  view.setUint16(32, channels * 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, "data");
  view.setUint32(40, data.length * 2, true);
  let offset = 44;
  for (let i = 0; i < data.length; i++) {
    const s = Math.max(-1, Math.min(1, data[i]!));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    offset += 2;
  }
  return new Blob([bytes], { type: "audio/wav" });
}

async function mixMono(buffer: AudioBuffer, maxSeconds: number): Promise<AudioBuffer> {
  const length = Math.min(buffer.length, Math.floor(buffer.sampleRate * maxSeconds));
  const ctx = new OfflineAudioContext(1, length, buffer.sampleRate);
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  const merger = ctx.createGain();
  src.connect(merger);
  merger.connect(ctx.destination);
  src.start(0);
  return ctx.startRendering();
}

async function resample(buffer: AudioBuffer, rate = 16000): Promise<AudioBuffer> {
  if (buffer.sampleRate === rate) return buffer;
  const duration = buffer.duration;
  const ctx = new OfflineAudioContext(1, Math.ceil(rate * duration), rate);
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  src.connect(ctx.destination);
  src.start(0);
  return ctx.startRendering();
}

export async function readVideoDuration(file: Blob): Promise<number> {
  const url = URL.createObjectURL(file);
  try {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.src = url;
    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error("Could not read video"));
    });
    return Number.isFinite(video.duration) ? video.duration : 0;
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function extractAudioChunks(
  file: Blob,
  maxSeconds = MAX_TRANSCRIBE_SECONDS,
  chunkSeconds = STT_CHUNK_SECONDS,
): Promise<{ chunks: { blob: Blob; filename: string; type: string; offset: number }[]; duration: number; truncated: boolean }> {
  if (file.size > MAX_DECODE_BYTES) {
    throw new Error("This file is too large to read in the browser.");
  }
  const raw = await file.arrayBuffer();
  const ctx = new AudioContext();
  let decoded: AudioBuffer;
  try {
    decoded = await ctx.decodeAudioData(raw.slice(0));
  } catch {
    await ctx.close();
    throw new Error("This file has no readable audio track.");
  }
  await ctx.close();

  const truncated = decoded.duration > maxSeconds;
  const total = await mixMono(decoded, maxSeconds);
  const resampled = await resample(total, 16000);
  const duration = resampled.duration;
  const chunks: { blob: Blob; filename: string; type: string; offset: number }[] = [];

  for (let offset = 0, i = 0; offset < duration; offset += chunkSeconds, i += 1) {
    const sliceDur = Math.min(chunkSeconds, duration - offset);
    const startSample = Math.floor(offset * resampled.sampleRate);
    const frameCount = Math.floor(sliceDur * resampled.sampleRate);
    const slice = new AudioBuffer({
      length: frameCount,
      numberOfChannels: 1,
      sampleRate: resampled.sampleRate,
    });
    slice.copyToChannel(resampled.getChannelData(0).subarray(startSample, startSample + frameCount), 0);
    // WAV encodes instantly. (The old MediaRecorder/Opus path ran in real time, so a
    // 1-hour video took an hour to "extract" and Safari fell back to oversized WAVs.)
    const wav = encodeWav(slice);
    chunks.push({ blob: wav, filename: `chunk-${i}.wav`, type: "audio/wav", offset });
  }

  return { chunks, duration, truncated };
}

export async function grabFrame(file: Blob, time: number, width = 270, height = 480): Promise<string | undefined> {
  const url = URL.createObjectURL(file);
  try {
    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    await new Promise<void>((resolve, reject) => {
      video.onloadeddata = () => resolve();
      video.onerror = () => reject(new Error("frame"));
    });
    const target = Math.min(Math.max(0.05, time), video.duration || time);
    video.currentTime = target;
    await new Promise<void>((resolve) => {
      video.onseeked = () => resolve();
      setTimeout(() => resolve(), 800);
    });
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx || !video.videoWidth) return undefined;
    const vr = video.videoWidth / video.videoHeight;
    const cr = width / height;
    let dw = width;
    let dh = height;
    let dx = 0;
    let dy = 0;
    if (vr > cr) {
      dh = height;
      dw = height * vr;
      dx = -(dw - width) / 2;
    } else {
      dw = width;
      dh = width / vr;
      dy = -(dh - height) / 2;
    }
    ctx.drawImage(video, dx, dy, dw, dh);
    return canvas.toDataURL("image/jpeg", 0.62);
  } catch {
    return undefined;
  } finally {
    URL.revokeObjectURL(url);
  }
}
