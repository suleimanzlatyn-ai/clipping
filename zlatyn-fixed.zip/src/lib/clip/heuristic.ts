import { groupSentences } from "./captions";
import type { Clip, ClipSettings, Word } from "./types";
import { LENGTH_RANGE } from "./types";

const HOT = [
  "never",
  "always",
  "secret",
  "mistake",
  "failed",
  "fail",
  "truth",
  "actually",
  "stop",
  "nobody",
  "everyone",
  "wrong",
  "broke",
  "rich",
  "million",
  "zero",
  "crazy",
  "insane",
  "honest",
  "confession",
  "advice",
  "killed",
  "hate",
  "love",
  "first",
  "last",
  "only",
  "why",
  "how",
  "don't",
  "dont",
  "won't",
  "wont",
  "can't",
  "cannot",
  "wait",
  "look",
  "listen",
];

function scoreSentence(words: Word[]): number {
  const text = words.map((w) => w.text).join(" ");
  const lower = text.toLowerCase();
  let score = 40;
  const count = words.length;
  if (count >= 8 && count <= 24) score += 12;
  if (/[?]/.test(text)) score += 10;
  if (/\d/.test(text)) score += 8;
  if (/you\b/.test(lower)) score += 6;
  for (const w of HOT) {
    if (new RegExp(`\\b${w}\\b`, "i").test(lower)) score += 7;
  }
  const span = (words[words.length - 1]?.end ?? 0) - (words[0]?.start ?? 0);
  if (span > 2 && span < 12) score += 6;
  return Math.min(99, score);
}

function windowAround(
  sentences: Word[][],
  index: number,
  min: number,
  max: number,
): { start: number; end: number; words: Word[] } | null {
  const seed = sentences[index];
  if (!seed?.length) return null;
  let startI = index;
  let endI = index;
  const all = () => sentences.slice(startI, endI + 1).flat();
  const span = (ws: Word[]) => (ws.at(-1)?.end ?? 0) - (ws[0]?.start ?? 0);

  while (span(all()) < min && (startI > 0 || endI < sentences.length - 1)) {
    const nextLen = endI < sentences.length - 1 ? span(sentences.slice(startI, endI + 2).flat()) : Infinity;
    const prevLen = startI > 0 ? span(sentences.slice(startI - 1, endI + 1).flat()) : Infinity;
    if (nextLen <= max && nextLen < prevLen) endI += 1;
    else if (prevLen <= max) startI -= 1;
    else if (nextLen !== Infinity) endI += 1;
    else break;
    if (span(all()) > max) break;
  }

  const words = all();
  if (words.length < 6) return null;
  const start = words[0]!.start;
  const end = words.at(-1)!.end;
  if (end - start < min * 0.7) return null;
  return { start, end: Math.min(end, start + max), words };
}

function overlaps(a: { start: number; end: number }, b: { start: number; end: number }): number {
  const left = Math.max(a.start, b.start);
  const right = Math.min(a.end, b.end);
  const inter = Math.max(0, right - left);
  const union = Math.max(a.end, b.end) - Math.min(a.start, b.start);
  return union <= 0 ? 0 : inter / union;
}

export function heuristicClips(words: Word[], settings: ClipSettings): Clip[] {
  if (words.length < 12) return [];
  const { min, max } = LENGTH_RANGE[settings.length];
  const sentences = groupSentences(words);
  const ranked = sentences
    .map((s, i) => ({ i, score: scoreSentence(s), s }))
    .sort((a, b) => b.score - a.score);

  const picked: Clip[] = [];
  for (const item of ranked) {
    if (picked.length >= 8) break;
    const win = windowAround(sentences, item.i, min, max);
    if (!win) continue;
    if (picked.some((c) => overlaps(c, win) > 0.35)) continue;
    const keywords = win.words
      .map((w) => w.text.replace(/[^a-zA-Z0-9']/g, ""))
      .filter((t) => t.length > 3 && HOT.includes(t.toLowerCase()))
      .slice(0, 4);
    const title = win.words
      .slice(0, 8)
      .map((w) => w.text)
      .join(" ")
      .replace(/[,.]+$/, "");
    picked.push({
      id: crypto.randomUUID(),
      start: win.start,
      end: win.end,
      title: title.length > 8 ? title : "Untitled moment",
      hook: title,
      score: Math.round(Math.min(96, item.score + (keywords.length ? 4 : 0))),
      reason: "A complete thought with a hard open — no preamble.",
      aspect: settings.aspect,
      reframe: 0.5,
    });
  }
  return picked.sort((a, b) => b.score - a.score);
}
