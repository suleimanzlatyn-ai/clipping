import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { stripFillers, wordsFromPlainTranscript } from "./captions";
import { dedupeBySpan, snapSpan } from "./refine";
import { heuristicClips } from "./heuristic";
import type { Clip, ClipSettings, Word } from "./types";
import { LENGTH_RANGE } from "./types";
import { allow, clientKey } from "../rate-limit.server";

type SttWord = { text: string; start: number; end: number; speaker?: number };

type ClipDraft = {
  startSec: number;
  endSec: number;
  title: string;
  hook: string;
  score: number;
  reason: string;
};

function parseClipsJson(text: string): ClipDraft[] {
  const cleaned = text.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const parsed = JSON.parse(cleaned) as { clips?: ClipDraft[] } | ClipDraft[];
  const list = Array.isArray(parsed) ? parsed : parsed.clips;
  if (!Array.isArray(list)) return [];
  return list.filter(
    (c) =>
      typeof c.startSec === "number" &&
      typeof c.endSec === "number" &&
      c.endSec > c.startSec,
  );
}

function draftsToClips(
  drafts: ClipDraft[],
  settings: ClipSettings,
  words: Word[],
  duration: number,
): Clip[] {
  const range = LENGTH_RANGE[settings.length];
  const snapped = drafts.flatMap((d) => {
    const span = snapSpan({ start: d.startSec, end: d.endSec }, words, range, duration);
    if (!span) return [];
    return [
      {
        ...span,
        score: Math.round(Math.min(99, Math.max(1, d.score || 70))),
        draft: d,
      },
    ];
  });
  return dedupeBySpan(snapped)
    .slice(0, 12)
    .map(({ start, end, score, draft }) => ({
      id: crypto.randomUUID(),
      start,
      end,
      title: (draft.title || "Untitled clip").slice(0, 90),
      hook: (draft.hook || draft.title || "").slice(0, 120),
      score,
      reason: (draft.reason || "").slice(0, 220),
      aspect: settings.aspect,
      reframe: 0.5,
    }));
}

const CLIP_SCHEMA = {
  type: "json_schema",
  json_schema: {
    name: "god_clips",
    schema: {
      type: "object",
      properties: {
        clips: {
          type: "array",
          items: {
            type: "object",
            properties: {
              startSec: { type: "number" },
              endSec: { type: "number" },
              title: { type: "string" },
              hook: { type: "string" },
              score: { type: "number" },
              reason: { type: "string" },
            },
            required: ["startSec", "endSec", "title", "hook", "score", "reason"],
            additionalProperties: false,
          },
        },
      },
      required: ["clips"],
      additionalProperties: false,
    },
    strict: true,
  },
} as const;

function compactTranscript(words: Word[]): string {
  const lines: string[] = [];
  let buf: Word[] = [];
  const flush = () => {
    if (!buf.length) return;
    const t = buf[0]!.start;
    const mm = Math.floor(t / 60);
    const ss = Math.floor(t % 60)
      .toString()
      .padStart(2, "0");
    lines.push(`[${mm}:${ss}] ${buf.map((w) => w.text).join(" ")}`);
    buf = [];
  };
  for (const word of words) {
    buf.push(word);
    if (buf.length >= 18 || /[.!?]$/.test(word.text)) flush();
  }
  flush();
  return lines.join("\n");
}

const SEGMENT_CHARS = 20000;
const MAX_SEGMENTS = 6;
const MAX_WORDS = 60000;

/** Split a long transcript on sentence boundaries so no part of the video is silently dropped. */
function segmentWords(words: Word[]): Word[][] {
  const totalChars = words.reduce((n, w) => n + w.text.length + 1, 0);
  const budget = Math.max(SEGMENT_CHARS, Math.ceil(totalChars / MAX_SEGMENTS) + 200);
  const segments: Word[][] = [];
  let cur: Word[] = [];
  let chars = 0;
  for (const w of words) {
    cur.push(w);
    chars += w.text.length + 1;
    if (chars >= budget && /[.!?]$/.test(w.text)) {
      segments.push(cur);
      cur = [];
      chars = 0;
    }
  }
  if (cur.length) segments.push(cur);
  return segments;
}

const SYSTEM_PROMPT =
  "You are a senior human editor cutting long-form for paid clip rewards. Output must look handmade: no TikTok caption energy, no 'wait for it', no 'nobody talks about this', no manufactured urgency. Open every clip on a complete spoken sentence. Never start mid-clause. Prefer specific numbers, confessions, reversals, proof, a named tension, a rule the viewer can steal. Reject intros, hey-guys, sponsors, recaps, and anything that needs the rest of the video. The hook field is the EXACT spoken opening line. The title is a private cut-list label, not a thumbnail. Score is hook strength 1-99. startSec and endSec are seconds from the start of the whole video, taken from the [m:ss] markers.";

async function askForClips(
  apiKey: string,
  segment: Word[],
  count: string,
  range: { min: number; max: number },
  duration: number,
  extra: string,
): Promise<ClipDraft[]> {
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0.35,
      max_tokens: 2500,
      response_format: CLIP_SCHEMA,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: `Video duration: ${Math.round(duration)}s. This excerpt covers ${Math.round(segment[0]!.start)}s to ${Math.round(segment.at(-1)!.end)}s. Target length ${range.min}-${range.max}s. Return ${count} non-overlapping clips from this excerpt only, strongest hooks first.${extra}\n\nTranscript:\n${compactTranscript(segment)}`,
        },
      ],
    }),
  });
  if (!res.ok) throw new Error(`Clipping failed (${res.status})`);
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return parseClipsJson(body.choices?.[0]?.message?.content ?? "");
}

export const generateClips = createServerFn({ method: "POST" })
  .validator(
    (input: { words: Word[]; duration: number; settings: ClipSettings; transcript: string }) => {
      if (!Array.isArray(input.words) || input.words.length > MAX_WORDS) {
        throw new Error("Transcript is too long to clip in one go.");
      }
      if (typeof input.transcript !== "string" || input.transcript.length > 600_000) {
        throw new Error("Transcript is too long to clip in one go.");
      }
      if (!(input.settings?.length in LENGTH_RANGE)) throw new Error("Bad clip settings.");
      return input;
    },
  )
  .handler(async ({ data }): Promise<{ ok: true; clips: Clip[] } | { ok: false; error: string; clips: Clip[] }> => {
    const words = data.settings.removeFillers ? stripFillers(data.words) : data.words;
    const fallback = heuristicClips(
      words.length ? words : wordsFromPlainTranscript(data.transcript, data.duration),
      data.settings,
    );
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: true, clips: fallback };
    }

    const range = LENGTH_RANGE[data.settings.length];
    const extra = data.settings.prompt.trim()
      ? `\nEditor brief: ${data.settings.prompt.trim().slice(0, 400)}`
      : "";
    const source = words.length ? words : wordsFromPlainTranscript(data.transcript, data.duration);
    if (!source.length) return { ok: true, clips: fallback };

    if (!allow(clientKey(getRequest()), "clip", 12, 10 * 60_000)) {
      return { ok: false, error: "Too many requests. Wait a few minutes.", clips: fallback };
    }

    try {
      const segments = segmentWords(source);
      const count = segments.length === 1 ? "8 to 12" : "3 to 5";
      const settled = await Promise.allSettled(
        segments.map((seg) => askForClips(apiKey, seg, count, range, data.duration, extra)),
      );
      const drafts = settled.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
      if (!drafts.length && settled.every((r) => r.status === "rejected")) {
        return { ok: false, error: "Clipping is unavailable", clips: fallback };
      }
      const clips = draftsToClips(drafts, data.settings, source, data.duration);
      // Strongest first, but keep the list in a stable, scannable order.
      clips.sort((a, b) => b.score - a.score);
      return { ok: true, clips: clips.length ? clips : fallback };
    } catch {
      return { ok: false, error: "Clipping is unavailable", clips: fallback };
    }
  });

export const rewriteCopy = createServerFn({ method: "POST" })
  .validator((input: { kind: "title" | "hook"; current: string; transcript: string }) => input)
  .handler(async ({ data }): Promise<{ ok: true; text: string } | { ok: false; error: string }> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "AI is not available" };
    if (!allow(clientKey(getRequest()), "rewrite", 40, 10 * 60_000)) {
      return { ok: false, error: "Too many requests. Wait a few minutes." };
    }
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.5,
          max_tokens: 80,
          messages: [
            {
              role: "system",
              content:
                data.kind === "title"
                  ? "Rewrite a private cut-list title. Max 10 words. Human. No quotes, hashtags, or clickbait. Return only the title."
                  : "Return the strongest spoken opening line from the clip, verbatim if it is already good. Max 14 words. No quotes.",
            },
            {
              role: "user",
              content: `Current: ${data.current}\nClip text:\n${data.transcript.slice(0, 900)}`,
            },
          ],
        }),
      });
      if (!res.ok) return { ok: false, error: `AI error ${res.status}` };
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = (body.choices?.[0]?.message?.content ?? "").replace(/^["']|["']$/g, "").trim();
      if (!text) return { ok: false, error: "Empty rewrite" };
      return { ok: true, text: text.slice(0, 120) };
    } catch {
      return { ok: false, error: "AI is not available" };
    }
  });

export function normalizeSttWords(words: SttWord[] | undefined, text: string, duration: number): Word[] {
  if (words?.length) {
    return words.map((w) => ({
      text: w.text,
      start: w.start > 10000 ? w.start / 1000 : w.start,
      end: w.end > 10000 ? w.end / 1000 : w.end,
      speaker: w.speaker,
    }));
  }
  return wordsFromPlainTranscript(text, duration);
}
