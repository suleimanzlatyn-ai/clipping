export type Aspect = "9:16" | "1:1" | "16:9";
export type LengthPreset = "auto" | "short" | "mid" | "long";
export type ProjectStatus = "queued" | "transcribing" | "clipping" | "ready" | "error";
export type SourceKind = "upload" | "sample" | "youtube";

export type Word = {
  text: string;
  start: number;
  end: number;
  speaker?: number;
};

export type ClipSettings = {
  length: LengthPreset;
  aspect: Aspect;
  prompt: string;
  removeFillers: boolean;
};

export type Clip = {
  id: string;
  start: number;
  end: number;
  title: string;
  hook: string;
  score: number;
  reason: string;
  thumbnail?: string;
  aspect: Aspect;
  reframe: number;
};

export type Project = {
  id: string;
  name: string;
  createdAt: number;
  duration: number;
  status: ProjectStatus;
  error?: string;
  progress: number;
  progressLabel: string;
  truncated?: boolean;
  settings: ClipSettings;
  words: Word[];
  transcript: string;
  language?: string;
  clips: Clip[];
  sourceKind: SourceKind;
  sourceName: string;
  youtubeId?: string;
  youtubeThumb?: string;
};

export type ProjectSummary = {
  id: string;
  name: string;
  createdAt: number;
  duration: number;
  status: ProjectStatus;
  clipCount: number;
  sourceKind: SourceKind;
  thumbnail?: string;
};

export const LENGTH_RANGE: Record<LengthPreset, { min: number; max: number; label: string }> = {
  auto: { min: 18, max: 45, label: "Auto" },
  short: { min: 12, max: 25, label: "15s" },
  mid: { min: 25, max: 45, label: "30s" },
  long: { min: 45, max: 90, label: "60s" },
};

export const MAX_TRANSCRIBE_SECONDS = 7200;
// 16 kHz mono 16-bit WAV is ~32 KB/s. 120 s -> ~3.84 MB, which stays under the
// 4.5 MB request-body limit on Vercel functions (and the /api/stt guard).
export const STT_CHUNK_SECONDS = 120;
// decodeAudioData needs the whole file in memory; past this the tab tends to crash.
export const MAX_DECODE_BYTES = 700 * 1024 * 1024;
