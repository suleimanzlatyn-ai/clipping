import type { Word } from "./types";

const FILLERS = new Set(["um", "uh", "erm", "er", "ah", "uhm", "uhh"]);

export function stripFillers(words: Word[]): Word[] {
  return words.filter((w) => !FILLERS.has(w.text.toLowerCase().replace(/[^a-z']/g, "")));
}

export function groupSentences(words: Word[]): Word[][] {
  const sentences: Word[][] = [];
  let current: Word[] = [];
  for (let i = 0; i < words.length; i++) {
    const word = words[i]!;
    current.push(word);
    const text = word.text;
    const next = words[i + 1];
    const gap = next ? next.start - word.end : 1;
    const punct = /[.!?]$/.test(text);
    if (punct || gap > 0.7 || current.length >= 28) {
      if (current.length) sentences.push(current);
      current = [];
    }
  }
  if (current.length) sentences.push(current);
  return sentences;
}

export function wordsFromPlainTranscript(text: string, duration: number): Word[] {
  const tokens = text
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!tokens.length || duration <= 0) return [];
  const avg = duration / tokens.length;
  return tokens.map((t, i) => ({
    text: t,
    start: i * avg,
    end: Math.min(duration, (i + 1) * avg),
  }));
}
