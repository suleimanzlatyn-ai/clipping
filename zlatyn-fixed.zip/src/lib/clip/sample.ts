import type { Clip, Project, Word } from "./types";

function w(text: string, start: number, dur = 0.32): Word {
  return { text, start, end: start + dur };
}

function seq(start: number, tokens: string[], pace = 0.34): Word[] {
  let t = start;
  return tokens.map((text) => {
    const dur = Math.max(0.16, text.length * 0.045 + (/[.!?]$/.test(text) ? 0.22 : 0.08));
    const word = w(text, t, dur);
    t += pace + (text.length > 6 ? 0.06 : 0);
    return word;
  });
}

const blocks: Word[][] = [
  seq(2.1, [
    "The", "advice", "that", "almost", "killed", "my", "company", "was",
    "post", "every", "day", "or", "you", "will", "die.",
  ]),
  seq(12.4, [
    "I", "believed", "it", "for", "fourteen", "months.", "We", "published",
    "two", "hundred", "and", "eleven", "videos.", "Revenue", "was", "zero.",
  ]),
  seq(24.8, [
    "Not", "slow.", "Zero.", "The", "algorithm", "did", "not", "owe", "us", "a", "living.",
  ]),
  seq(38.2, [
    "Here", "is", "what", "actually", "changed", "the", "business.", "We", "stopped",
    "posting", "and", "started", "cutting.",
  ]),
  seq(52.6, [
    "One", "long", "conversation.", "Eight", "shorts.", "The", "same", "week",
    "a", "clip", "hit", "a", "million", "views.",
  ]),
  seq(68.0, [
    "Stop", "trying", "to", "be", "everywhere.", "Be", "unforgettable", "in",
    "one", "place", "first.",
  ]),
  seq(82.4, [
    "People", "do", "not", "share", "information.", "They", "share", "identity.",
    "If", "your", "clip", "does", "not", "make", "them", "look", "smart,",
    "it", "does", "not", "travel.",
  ]),
  seq(102.8, [
    "The", "hook", "is", "not", "a", "caption.", "The", "hook", "is", "a",
    "promise", "you", "can", "keep", "in", "twenty", "seconds.",
  ]),
  seq(118.2, [
    "If", "you", "cannot", "say", "the", "point", "out", "loud", "in", "one",
    "breath,", "the", "clip", "is", "not", "done.",
  ]),
  seq(134.0, [
    "We", "made", "the", "same", "mistake", "everyone", "makes.", "We", "edited",
    "for", "ourselves.", "Viewers", "do", "not", "owe", "you", "context.",
  ]),
  seq(152.4, [
    "Cut", "the", "preamble.", "Start", "on", "the", "sentence", "that", "hurts",
    "a", "little", "to", "say.",
  ]),
  seq(166.8, [
    "I", "used", "to", "think", "virality", "was", "luck.", "It", "is", "pattern",
    "recognition", "with", "better", "taste.",
  ]),
  seq(184.2, [
    "Watch", "the", "first", "three", "seconds", "on", "mute.", "If", "it", "still",
    "makes", "sense,", "you", "have", "a", "shot.",
  ]),
  seq(200.6, [
    "Nobody", "wants", "your", "whole", "podcast.", "They", "want", "the", "line",
    "they", "will", "repeat", "at", "dinner.",
  ]),
  seq(216.4, [
    "That", "is", "the", "job.", "Find", "the", "line.", "Protect", "it.", "Ship", "it", "today.",
  ]),
];

export const SAMPLE_WORDS: Word[] = blocks.flat();
export const SAMPLE_DURATION = 232;

const SAMPLE_TRANSCRIPT = SAMPLE_WORDS.map((w) => w.text).join(" ");

type Draft = {
  start: number;
  end: number;
  title: string;
  hook: string;
  score: number;
  reason: string;
};

const DRAFTS: Draft[] = [
  {
    start: 2.1,
    end: 36.5,
    title: "The advice that almost killed my company",
    hook: "Post every day or you will die.",
    score: 96,
    reason: "A sharp confession with a number and a reversal — classic first-three-seconds stop-scroll.",
  },
  {
    start: 38.2,
    end: 66.8,
    title: "We stopped posting and started cutting",
    hook: "One conversation. Eight shorts. A million views.",
    score: 93,
    reason: "Concrete outcome plus a simple method. Viewers can steal the playbook.",
  },
  {
    start: 68.0,
    end: 100.4,
    title: "People share identity, not information",
    hook: "If the clip does not make them look smart, it does not travel.",
    score: 91,
    reason: "A quotable rule that feels like a secret about how sharing actually works.",
  },
  {
    start: 102.8,
    end: 132.0,
    title: "A hook is a promise you can keep",
    hook: "The hook is not a caption.",
    score: 88,
    reason: "Reframes a tired term. Short, teachable, and immediately usable.",
  },
  {
    start: 134.0,
    end: 164.8,
    title: "Viewers do not owe you context",
    hook: "Start on the sentence that hurts a little to say.",
    score: 84,
    reason: "Emotional instruction with a clear edit action. Strong for talking-head channels.",
  },
  {
    start: 184.2,
    end: 228.4,
    title: "Watch the first three seconds on mute",
    hook: "Nobody wants your whole podcast.",
    score: 82,
    reason: "Ends on a mission: find the line, protect it, ship it. Clean call to action.",
  },
];

function toClip(draft: Draft): Clip {
  return {
    id: `sample-${draft.start}`,
    start: draft.start,
    end: draft.end,
    title: draft.title,
    hook: draft.hook,
    score: draft.score,
    reason: draft.reason,
    aspect: "9:16",
    reframe: 0.5,
  };
}

export function createSampleProject(): Project {
  const clips = DRAFTS.map(toClip);
  return {
    id: crypto.randomUUID(),
    name: "Sample — Founder interview",
    createdAt: Date.now(),
    duration: SAMPLE_DURATION,
    status: "ready",
    progress: 100,
    progressLabel: "Ready",
    settings: {
      length: "mid",
      aspect: "9:16",
      prompt: "Find the sharpest takes and quotable rules.",
      removeFillers: true,
    },
    words: SAMPLE_WORDS,
    transcript: SAMPLE_TRANSCRIPT,
    language: "en",
    clips,
    sourceKind: "sample",
    sourceName: "sample-interview",
  };
}
