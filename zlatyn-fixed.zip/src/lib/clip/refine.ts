import type { Word } from "./types";

export type Span = { start: number; end: number };

/** Indices of words that open a sentence (start of text, after .!? or after a pause). */
function sentenceStartIndexes(words: Word[]): number[] {
  const out: number[] = [];
  for (let i = 0; i < words.length; i++) {
    if (i === 0) {
      out.push(0);
      continue;
    }
    const prev = words[i - 1]!;
    if (/[.!?]["')\]]?$/.test(prev.text) || words[i]!.start - prev.end > 0.7) out.push(i);
  }
  return out;
}

function nearest(values: number[], target: number): number {
  let best = values[0] ?? target;
  let dist = Infinity;
  for (const v of values) {
    const d = Math.abs(v - target);
    if (d < dist) {
      dist = d;
      best = v;
    }
  }
  return best;
}

export function overlapRatio(a: Span, b: Span): number {
  const inter = Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));
  const union = Math.max(a.end, b.end) - Math.min(a.start, b.start);
  return union <= 0 ? 0 : inter / union;
}

/**
 * Models give approximate timestamps. Snap the cut to real speech so a clip opens on
 * the first word of a sentence and closes on the last word of one, and keep it inside
 * the length range and the video. Returns null if nothing sensible is left.
 */
export function snapSpan(
  draft: Span,
  words: Word[],
  range: { min: number; max: number },
  duration: number,
): Span | null {
  if (!words.length) return null;
  const starts = sentenceStartIndexes(words).map((i) => words[i]!.start);
  const ends = words.map((w) => w.end);

  const windowStart = starts.filter((t) => Math.abs(t - draft.start) <= 6);
  let start = windowStart.length ? nearest(windowStart, draft.start) : nearest(starts, draft.start);

  const maxLen = range.max * 1.25;
  const minLen = Math.max(6, range.min * 0.6);
  const ceiling = duration > 0 ? Math.min(duration, words.at(-1)!.end) : words.at(-1)!.end;

  const candidates = ends.filter((t) => t - start >= minLen && t - start <= maxLen && t <= ceiling + 0.01);
  if (!candidates.length) return null;
  // Prefer an end that lands on sentence-final punctuation near the model's choice.
  const sentenceEnds = candidates.filter((t) => {
    const w = words.find((x) => x.end === t);
    return w ? /[.!?]["')\]]?$/.test(w.text) : false;
  });
  const pool = sentenceEnds.length ? sentenceEnds : candidates;
  let end = nearest(pool, Math.min(draft.end, start + maxLen));

  start = Math.max(0, start);
  end = Math.min(end, ceiling);
  if (end - start < minLen) return null;
  return { start, end };
}

/** Keep the strongest clip when two overlap too much. Input order is irrelevant. */
export function dedupeBySpan<T extends Span & { score: number }>(clips: T[], maxOverlap = 0.35): T[] {
  const sorted = [...clips].sort((a, b) => b.score - a.score);
  const kept: T[] = [];
  for (const clip of sorted) {
    if (kept.some((k) => overlapRatio(k, clip) > maxOverlap)) continue;
    kept.push(clip);
  }
  return kept;
}
