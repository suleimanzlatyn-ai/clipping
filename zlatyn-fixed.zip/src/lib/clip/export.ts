import type { Clip } from "./types";

export type AspectSize = { width: number; height: number };

export function exportSize(aspect: Clip["aspect"]): AspectSize {
  if (aspect === "1:1") return { width: 1080, height: 1080 };
  if (aspect === "16:9") return { width: 1920, height: 1080 };
  return { width: 1080, height: 1920 };
}

export function drawCover(
  ctx: CanvasRenderingContext2D,
  source: CanvasImageSource,
  sw: number,
  sh: number,
  dw: number,
  dh: number,
  reframe: number,
) {
  const vr = sw / sh;
  const cr = dw / dh;
  let w = dw;
  let h = dh;
  let x = 0;
  let y = 0;
  if (vr > cr) {
    h = dh;
    w = dh * vr;
    x = -(w - dw) * reframe;
  } else {
    w = dw;
    h = dw / vr;
    y = -(h - dh) * 0.5;
  }
  ctx.drawImage(source, x, y, w, h);
}

type AudioTap = { ctx: AudioContext; dest: MediaStreamAudioDestinationNode };
const audioTaps = new WeakMap<HTMLVideoElement, AudioTap>();

/**
 * canvas.captureStream() carries no sound, so the old export was silent. Route the
 * <video> through WebAudio once (createMediaElementSource may only be called once
 * per element) and feed both the speakers and a MediaStream the recorder can mux.
 */
async function tapAudio(video: HTMLVideoElement): Promise<AudioTap | null> {
  try {
    let tap = audioTaps.get(video);
    if (!tap) {
      const ctx = new AudioContext();
      const source = ctx.createMediaElementSource(video);
      const dest = ctx.createMediaStreamDestination();
      source.connect(dest);
      source.connect(ctx.destination);
      tap = { ctx, dest };
      audioTaps.set(video, tap);
    }
    if (tap.ctx.state === "suspended") await tap.ctx.resume();
    return tap;
  } catch {
    return null;
  }
}

const MIME_CANDIDATES = [
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8,opus",
  "video/webm",
  "video/mp4",
];

function pickMime(): string {
  if (typeof MediaRecorder === "undefined") return "";
  return MIME_CANDIDATES.find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
}

export function extensionForBlob(blob: Blob): string {
  return blob.type.includes("mp4") ? "mp4" : "webm";
}

export async function exportClip(options: {
  clip: Clip;
  video: HTMLVideoElement | null;
  onProgress?: (pct: number) => void;
}): Promise<Blob> {
  const { clip, video, onProgress } = options;
  if (!video || !video.videoWidth) {
    throw new Error("Attach the source video to export a clean cut.");
  }
  const { width, height } = exportSize(clip.aspect);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not export");

  const mime = pickMime();
  if (!mime) throw new Error("This browser cannot record video. Try Chrome, Edge or Firefox.");

  const stream = canvas.captureStream(30);
  const tap = await tapAudio(video);
  if (tap) {
    for (const track of tap.dest.stream.getAudioTracks()) stream.addTrack(track);
  }
  const rec = new MediaRecorder(stream, {
    mimeType: mime,
    videoBitsPerSecond: 8_000_000,
    audioBitsPerSecond: 128_000,
  });
  const chunks: BlobPart[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };

  const duration = Math.max(1, clip.end - clip.start);
  video.pause();
  video.currentTime = clip.start;
  await new Promise<void>((resolve) => {
    const done = () => resolve();
    video.addEventListener("seeked", done, { once: true });
    setTimeout(done, 600);
  });

  const stopped = new Promise<Blob>((resolve) => {
    rec.onstop = () => resolve(new Blob(chunks, { type: mime }));
  });
  rec.start(200);

  const t0 = performance.now();
  await new Promise<void>((resolve) => {
    const tick = () => {
      const elapsed = (performance.now() - t0) / 1000;
      if (elapsed >= duration) {
        resolve();
        return;
      }
      const mediaTime = clip.start + elapsed;
      if (Math.abs(video.currentTime - mediaTime) > 0.35) {
        video.currentTime = mediaTime;
      }
      if (video.paused) void video.play();
      drawCover(ctx, video, video.videoWidth, video.videoHeight, width, height, clip.reframe);
      onProgress?.(Math.min(99, (elapsed / duration) * 100));
      requestAnimationFrame(tick);
    };
    void video.play();
    requestAnimationFrame(tick);
  });

  video.pause();
  rec.stop();
  const blob = await stopped;
  onProgress?.(100);
  return blob;
}
