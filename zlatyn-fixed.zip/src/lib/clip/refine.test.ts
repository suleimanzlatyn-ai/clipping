import assert from "node:assert/strict";
import test from "node:test";
import { dedupeBySpan, overlapRatio, snapSpan } from "./refine.ts";

function speech(): { text: string; start: number; end: number }[] {
  // Three sentences, ~10 s each, 0.3 s per word.
  const out: { text: string; start: number; end: number }[] = [];
  let t = 0;
  for (let s = 0; s < 6; s++) {
    for (let i = 0; i < 12; i++) {
      out.push({ text: i === 11 ? `end${s}.` : `w${s}_${i}`, start: t, end: t + 0.3 });
      t += 0.3;
    }
    t += 0.8; // pause between sentences
  }
  return out;
}

test("snapSpan opens on a sentence start and closes on a sentence end", () => {
  const words = speech();
  const span = snapSpan({ start: 4.9, end: 27 }, words, { min: 18, max: 45 }, 60);
  assert.ok(span);
  const first = words.find((w) => w.start === span!.start);
  const last = words.find((w) => w.end === span!.end);
  assert.ok(first && /^w\d_0$/.test(first.text), "starts at first word of a sentence");
  assert.ok(last && last.text.endsWith("."), "ends on a sentence-final word");
});

test("snapSpan never runs past the video", () => {
  const words = speech();
  const span = snapSpan({ start: 0, end: 500 }, words, { min: 18, max: 45 }, 30);
  assert.ok(span);
  assert.ok(span!.end <= 30);
});

test("snapSpan rejects spans that cannot reach the minimum length", () => {
  const words = speech().slice(0, 12);
  assert.equal(snapSpan({ start: 0, end: 3 }, words, { min: 18, max: 45 }, 60), null);
});

test("dedupeBySpan keeps the higher-scoring of two overlapping clips", () => {
  const kept = dedupeBySpan([
    { start: 0, end: 30, score: 60 },
    { start: 2, end: 31, score: 90 },
    { start: 100, end: 130, score: 70 },
  ]);
  assert.equal(kept.length, 2);
  assert.equal(kept[0]!.score, 90);
});

test("overlapRatio is 0 for disjoint spans and 1 for identical spans", () => {
  assert.equal(overlapRatio({ start: 0, end: 5 }, { start: 6, end: 9 }), 0);
  assert.equal(overlapRatio({ start: 1, end: 5 }, { start: 1, end: 5 }), 1);
});
