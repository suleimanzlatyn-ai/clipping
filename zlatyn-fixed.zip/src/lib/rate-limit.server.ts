/**
 * Tiny in-memory sliding-window limiter. It protects the owner's XAI_API_KEY from a
 * casual hammering of /api/stt and the AI server functions. On serverless each warm
 * instance keeps its own counters, so treat it as a speed bump, not a guarantee: for
 * real protection add Vercel Firewall rate limits or turn on sign-in.
 */
const hits = new Map<string, number[]>();

export function clientKey(request: Request): string {
  const fwd = request.headers.get("x-forwarded-for") ?? "";
  return fwd.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";
}

export function allow(key: string, bucket: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const id = `${bucket}:${key}`;
  const recent = (hits.get(id) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    hits.set(id, recent);
    return false;
  }
  recent.push(now);
  hits.set(id, recent);
  if (hits.size > 5000) {
    for (const [k, v] of hits) if (!v.some((t) => now - t < windowMs)) hits.delete(k);
  }
  return true;
}
