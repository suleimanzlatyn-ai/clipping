import { createFileRoute } from "@tanstack/react-router";
import { normalizeSttWords } from "@/lib/clip/ai";
import { allow, clientKey } from "@/lib/rate-limit.server";

export const Route = createFileRoute("/api/stt")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json({ ok: false, error: "AI is not available in this environment" }, { status: 503 });
        }

        // ~120 s chunks: a 2-hour file is ~60 requests, so allow a few of those per window.
        if (!allow(clientKey(request), "stt", 90, 30 * 60_000)) {
          return Response.json({ ok: false, error: "Too many requests. Wait a few minutes." }, { status: 429 });
        }

        const form = await request.formData();
        const file = form.get("file");
        if (!(file instanceof Blob) || file.size < 32) {
          return Response.json({ ok: false, error: "No audio received" }, { status: 400 });
        }
        if (file.size > 4_500_000) {
          return Response.json({ ok: false, error: "Audio is too large. Try a shorter video." }, { status: 413 });
        }

        const filename = file instanceof File && file.name ? file.name : "audio.webm";
        const type = file.type || "application/octet-stream";

        const outbound = new FormData();
        outbound.append("model", "grok-voice-transcribe-2.0");
        outbound.append("format", "true");
        outbound.append("language", "en");
        outbound.append("file", file, filename);

        const res = await fetch("https://api.x.ai/v1/stt", {
          method: "POST",
          headers: { Authorization: `Bearer ${apiKey}` },
          body: outbound,
        });

        if (!res.ok) {
          const detail = await res.text().catch(() => "");
          return Response.json(
            { ok: false, error: `Transcription failed (${res.status})`, detail: detail.slice(0, 240) },
            { status: 502 },
          );
        }

        const body = (await res.json()) as {
          text?: string;
          language?: string;
          duration?: number;
          words?: { text: string; start: number; end: number; speaker?: number }[];
        };
        const text = body.text ?? "";
        const duration = body.duration ?? 0;
        return Response.json({
          ok: true,
          text,
          language: body.language,
          duration,
          words: normalizeSttWords(body.words, text, duration || 1),
          type,
        });
      },
    },
  },
});
