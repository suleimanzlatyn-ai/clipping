import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ClipEditor } from "@/components/studio/clip-editor";
import { ClipGrid } from "@/components/studio/clip-grid";
import { ProcessingView } from "@/components/studio/processing";
import { SiteHeader } from "@/components/studio/site-header";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { wordsFromPlainTranscript } from "@/lib/clip/captions";
import { deleteProject, getFile, getProject, saveProject } from "@/lib/clip/idb";
import { attachFileToProject, runPipeline } from "@/lib/clip/pipeline";
import type { Clip, Project } from "@/lib/clip/types";
import { formatClock } from "@/lib/utils";

export const Route = createFileRoute("/studio/$id")({
  component: StudioPage,
});

function cutList(project: Project): string {
  const lines = project.clips.map(
    (c, i) =>
      `${i + 1}. ${formatClock(c.start)}–${formatClock(c.end)}  ${c.hook}\n   ${c.title}  (hook ${c.score})`,
  );
  return `${project.name}\n${lines.join("\n")}`;
}

function StudioPage() {
  const { id } = Route.useParams();
  const fileRef = useRef<HTMLInputElement>(null);
  const [project, setProject] = useState<Project | null>(null);
  const [missing, setMissing] = useState(false);
  const [src, setSrc] = useState<string | null>(null);
  const [clipId, setClipId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [retrying, setRetrying] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let created: string | undefined;
    void (async () => {
      const loaded = await getProject(id);
      if (cancelled) return;
      if (!loaded) {
        setMissing(true);
        return;
      }
      setProject(loaded);
      const file = await getFile(id);
      if (cancelled) return;
      if (file) {
        created = URL.createObjectURL(file);
        setSrc(created);
      }
      if (loaded.status !== "ready" && loaded.status !== "error") {
        const next = await runPipeline(id, (updated) => {
          if (!cancelled) setProject(updated);
        });
        if (!cancelled) setProject(next);
      }
    })();
    return () => {
      cancelled = true;
      if (created) URL.revokeObjectURL(created);
    };
  }, [id]);

  async function persist(next: Project) {
    setProject(next);
    await saveProject(next);
  }

  function updateClip(clip: Clip) {
    if (!project) return;
    void persist({
      ...project,
      clips: project.clips.map((c) => (c.id === clip.id ? clip : c)),
    });
  }

  async function onAttach(file: File) {
    const next = await attachFileToProject(id, file);
    if (!next) return;
    setSrc((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
    setProject(next);
    toast.success("Source attached");
  }

  async function retry() {
    if (!project) return;
    setRetrying(true);
    try {
      const words = draft.trim()
        ? wordsFromPlainTranscript(draft, project.duration || 60)
        : project.words;
      const seeded: Project = {
        ...project,
        transcript: draft.trim() || project.transcript,
        words,
        status: "queued",
        error: undefined,
        progress: 8,
        progressLabel: "Hunting the hook",
      };
      await saveProject(seeded);
      setProject(seeded);
      const next = await runPipeline(id, setProject);
      setProject(next);
      if (next.status === "error") toast.error(next.error || "Still could not clip this video");
    } finally {
      setRetrying(false);
    }
  }

  const clip = project?.clips.find((c) => c.id === clipId) ?? null;

  return (
    <div className="min-h-dvh">
      <SiteHeader
        right={
          project ? (
            <>
              <span className="hidden text-xs tabular-nums text-muted-foreground sm:inline">
                {project.clips.length} clips · {formatClock(project.duration)}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  void deleteProject(id).then(() => {
                    window.location.href = "/";
                  });
                }}
              >
                Delete
              </Button>
            </>
          ) : null
        }
      />

      {!project && !missing ? (
        <div className="mx-auto max-w-lg px-4 py-24">
          <div className="h-3 w-40 rounded-full bg-secondary" />
          <div className="mt-6 h-10 w-72 rounded-md bg-secondary" />
          <div className="mt-8 h-1 w-full rounded-full bg-secondary" />
        </div>
      ) : null}

      {missing ? (
        <div className="px-4 py-24 text-center">
          <h1 className="font-display text-3xl tracking-tight">This project is gone</h1>
          <p className="mt-2 text-sm text-muted-foreground">It lives only in this browser.</p>
          <Button asChild className="mt-6">
            <Link to="/">Back to desk</Link>
          </Button>
        </div>
      ) : null}

      {project && (project.status === "queued" || project.status === "transcribing" || project.status === "clipping") ? (
        <ProcessingView project={project} />
      ) : null}

      {project?.status === "error" ? (
        <div className="mx-auto max-w-lg px-4 py-16">
          <p className="text-xs font-medium tracking-[0.2em] text-muted-foreground uppercase">Needs a transcript</p>
          <h1 className="font-display mt-3 text-4xl tracking-tight">{project.name}</h1>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            {project.error} Paste a transcript to continue without speech-to-text.
          </p>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            Pasted text has no timestamps, so cut points are spread evenly across the video and will be
            approximate. Check each clip&apos;s in/out before exporting.
          </p>
          <Textarea
            className="mt-6 min-h-40"
            placeholder="Paste the transcript here"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
          />
          <Button className="mt-4 w-full" disabled={retrying} onClick={() => void retry()}>
            {retrying ? "Clipping…" : "Clip from transcript"}
          </Button>
        </div>
      ) : null}

      {project?.status === "ready" && clip ? (
        <ClipEditor
          project={project}
          clip={clip}
          src={src}
          onChange={updateClip}
          onBack={() => setClipId(null)}
          onAttach={(file) => void onAttach(file)}
        />
      ) : null}

      {project?.status === "ready" && !clip ? (
        <div className="mx-auto max-w-6xl px-4 pb-20 sm:px-8">
          <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs font-medium tracking-[0.2em] text-muted-foreground uppercase">
                {project.sourceKind === "youtube" ? "YouTube" : project.sourceKind === "sample" ? "Sample" : "File"}
              </p>
              <h1 className="font-display mt-2 text-4xl tracking-tight">{project.name}</h1>
            </div>
            <div className="flex flex-wrap gap-2">
              <input
                ref={fileRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void onAttach(file);
                }}
              />
              {!src ? (
                <Button variant="secondary" size="sm" onClick={() => fileRef.current?.click()}>
                  Attach source
                </Button>
              ) : null}
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  void navigator.clipboard.writeText(cutList(project)).then(
                    () => toast.success("Cut list copied"),
                    () => toast.error("Could not copy"),
                  );
                }}
              >
                Copy cut list
              </Button>
            </div>
          </div>
          {project.truncated ? (
            <p className="mb-4 text-xs text-muted-foreground">Stopped reading audio at two hours.</p>
          ) : null}
          <ClipGrid clips={project.clips} onOpen={setClipId} />
        </div>
      ) : null}
    </div>
  );
}
