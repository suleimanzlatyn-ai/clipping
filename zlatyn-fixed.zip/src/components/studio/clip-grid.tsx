import { Play } from "lucide-react";
import type { Clip } from "@/lib/clip/types";
import { formatClock } from "@/lib/utils";

export function ClipGrid({
  clips,
  onOpen,
}: {
  clips: Clip[];
  onOpen: (id: string) => void;
}) {
  if (!clips.length) {
    return (
      <div className="rounded-xl bg-card px-6 py-16 text-center shadow-[var(--shadow-border)]">
        <p className="font-display text-2xl tracking-tight">No clips yet</p>
        <p className="mt-2 text-sm text-muted-foreground">Try a looser brief, or paste a transcript.</p>
      </div>
    );
  }

  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {clips.map((clip) => (
        <li key={clip.id}>
          <button
            type="button"
            onClick={() => onOpen(clip.id)}
            className="group flex w-full flex-col overflow-hidden rounded-xl bg-card text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-200 hover:shadow-[var(--shadow-border-hover)]"
          >
            <span className="relative aspect-portrait overflow-hidden bg-elevated">
              {clip.thumbnail ? (
                <img src={clip.thumbnail} alt="" className="size-full object-cover" />
              ) : (
                <span className="absolute inset-0 bg-elevated">
                  <span className="grain absolute inset-0 opacity-30" />
                  <span className="font-display absolute top-4 left-4 text-6xl leading-none tracking-tight text-paper tabular-nums">
                    {clip.score}
                  </span>
                </span>
              )}
              <span className="absolute inset-0 bg-linear-to-t from-ink via-transparent to-transparent" />
              <span className="absolute top-3 right-3 rounded-full bg-ink/60 px-2 py-0.5 text-xs tabular-nums text-paper/80">
                {formatClock(clip.end - clip.start)}
              </span>
              <span className="absolute bottom-3 left-3 right-3">
                <span className="font-display line-clamp-2 text-lg leading-snug tracking-tight text-paper">
                  {clip.title}
                </span>
              </span>
              <span className="absolute top-1/2 left-1/2 grid size-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-paper/0 text-paper opacity-0 transition-opacity duration-150 group-hover:bg-paper/90 group-hover:text-ink group-hover:opacity-100">
                <Play className="ml-0.5 size-4 fill-current" />
              </span>
            </span>
            <span className="px-4 py-3">
              <span className="line-clamp-2 text-sm text-foreground">{clip.hook}</span>
              <span className="mt-1 block text-xs text-muted-foreground">Hook {clip.score}</span>
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}
