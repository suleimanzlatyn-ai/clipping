import { Play } from "lucide-react";
import { useEffect, useRef, type RefObject } from "react";
import type { Clip } from "@/lib/clip/types";
import { cn } from "@/lib/utils";

const ASPECT_CLASS: Record<Clip["aspect"], string> = {
  "9:16": "aspect-portrait",
  "1:1": "aspect-square",
  "16:9": "aspect-wide",
};

export function Stage({
  clip,
  src,
  youtubeId,
  poster,
  playing,
  onPlayingChange,
  className,
  videoRef,
}: {
  clip: Clip;
  src?: string | null;
  youtubeId?: string;
  poster?: string;
  playing: boolean;
  onPlayingChange: (next: boolean) => void;
  className?: string;
  videoRef?: RefObject<HTMLVideoElement | null>;
}) {
  const innerRef = useRef<HTMLVideoElement>(null);
  const video = videoRef ?? innerRef;

  useEffect(() => {
    const el = video.current;
    if (el && src) el.currentTime = clip.start;
  }, [clip.id, clip.start, src, video]);

  useEffect(() => {
    const el = video.current;
    if (!el || !src) return;
    if (playing) void el.play().catch(() => onPlayingChange(false));
    else el.pause();
  }, [playing, src, video, onPlayingChange]);

  useEffect(() => {
    const el = video.current;
    if (!src || !el) return;
    const onTime = () => {
      if (el.currentTime >= clip.end - 0.05) {
        el.currentTime = clip.start;
        el.pause();
        onPlayingChange(false);
      }
    };
    el.addEventListener("timeupdate", onTime);
    return () => el.removeEventListener("timeupdate", onTime);
  }, [playing, src, clip.end, clip.start, clip.id, video, onPlayingChange]);

  const objectPos = `${Math.round(clip.reframe * 100)}% 50%`;
  const start = Math.max(0, Math.floor(clip.start));
  const end = Math.max(start + 1, Math.ceil(clip.end));

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border)]",
        ASPECT_CLASS[clip.aspect],
        className,
      )}
    >
      {src ? (
        <button
          type="button"
          className="absolute inset-0"
          onClick={() => onPlayingChange(!playing)}
          aria-label={playing ? "Pause clip" : "Play clip"}
        >
          <video
            ref={video}
            src={src}
            playsInline
            className="absolute inset-0 size-full object-cover"
            style={{ objectPosition: objectPos }}
          />
          {!playing ? (
            <span className="absolute top-1/2 left-1/2 grid size-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-paper/90 text-ink">
              <Play className="ml-0.5 size-5 fill-current" />
            </span>
          ) : null}
        </button>
      ) : youtubeId && playing ? (
        <iframe
          title={clip.title}
          className="absolute inset-0 size-full"
          src={`https://www.youtube-nocookie.com/embed/${youtubeId}?start=${start}&end=${end}&autoplay=1&rel=0&modestbranding=1`}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      ) : (
        <button
          type="button"
          className="absolute inset-0"
          onClick={() => onPlayingChange(true)}
          aria-label="Play clip"
        >
          {poster ? (
            <img src={poster} alt="" className="absolute inset-0 size-full object-cover" />
          ) : (
            <span className="grain absolute inset-0 opacity-30" />
          )}
          <span className="absolute inset-0 bg-ink/35" />
          <span className="absolute top-1/2 left-1/2 grid size-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-paper/90 text-ink">
            <Play className="ml-0.5 size-5 fill-current" />
          </span>
        </button>
      )}
    </div>
  );
}
