import { Copy, Download, Link2, RefreshCw, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { rewriteCopy } from "@/lib/clip/ai";
import { exportClip, extensionForBlob } from "@/lib/clip/export";
import type { Aspect, Clip, Project } from "@/lib/clip/types";
import { formatClock, slugify } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Stage } from "./stage";

const ASPECTS: Aspect[] = ["9:16", "1:1", "16:9"];

function youtubeWatch(id: string, start: number) {
  return `https://www.youtube.com/watch?v=${id}&t=${Math.floor(start)}s`;
}

export function ClipEditor({
  project,
  clip,
  src,
  onChange,
  onBack,
  onAttach,
}: {
  project: Project;
  clip: Clip;
  src?: string | null;
  onChange: (clip: Clip) => void;
  onBack: () => void;
  onAttach?: (file: File) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [playing, setPlaying] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [rewriting, setRewriting] = useState<"title" | "hook" | null>(null);

  const duration = Math.max(1, clip.end - clip.start);
  const clipText = project.words
    .filter((w) => w.end > clip.start && w.start < clip.end)
    .map((w) => w.text)
    .join(" ");

  async function copy(text: string, ok: string) {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(ok);
    } catch {
      toast.error("Could not copy");
    }
  }

  async function onRewrite(kind: "title" | "hook") {
    setRewriting(kind);
    try {
      const result = await rewriteCopy({
        data: { kind, current: kind === "title" ? clip.title : clip.hook, transcript: clipText },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      onChange(kind === "title" ? { ...clip, title: result.text } : { ...clip, hook: result.text });
    } finally {
      setRewriting(null);
    }
  }

  async function onExport() {
    if (!src || !videoRef.current) {
      toast.error("Attach the source video to export a clean cut.");
      fileRef.current?.click();
      return;
    }
    setExporting(true);
    setProgress(0);
    try {
      const blob = await exportClip({
        clip,
        video: videoRef.current,
        onProgress: setProgress,
      });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${slugify(clip.title)}.${extensionForBlob(blob)}`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      toast.success("Clean cut downloaded");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not export this clip");
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 pb-16 lg:grid-cols-[minmax(0,320px)_1fr] lg:px-8">
      <div>
        <button
          type="button"
          onClick={onBack}
          className="mb-4 text-xs font-medium tracking-wide text-muted-foreground hover:text-foreground"
        >
          All clips
        </button>
        <Stage
          clip={clip}
          src={src}
          youtubeId={project.youtubeId}
          poster={clip.thumbnail ?? project.youtubeThumb}
          playing={playing}
          onPlayingChange={setPlaying}
          videoRef={videoRef}
          className="w-full"
        />
        <p className="mt-3 text-center font-mono text-xs tabular-nums text-muted-foreground">
          {formatClock(clip.start)} – {formatClock(clip.end)} · {formatClock(duration)}
        </p>
      </div>

      <div className="space-y-6">
        <div>
          <p className="text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase">Spoken hook</p>
          <p className="font-display mt-2 text-2xl leading-snug tracking-tight">{clip.hook}</p>
          <p className="mt-2 text-xs text-muted-foreground">
            This line is already in the cut. It is not burned onto the picture.
          </p>
        </div>

        <div>
          <div className="flex items-center justify-between gap-3">
            <Label htmlFor="title">Cut label</Label>
            <button
              type="button"
              className="inline-flex min-h-11 items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
              onClick={() => void onRewrite("title")}
              disabled={rewriting !== null}
            >
              <RefreshCw className="size-3" /> Rewrite
            </button>
          </div>
          <Input
            id="title"
            className="mt-1.5"
            value={clip.title}
            onChange={(e) => onChange({ ...clip, title: e.target.value })}
          />
        </div>

        <div>
          <div className="flex items-center justify-between gap-3">
            <Label htmlFor="hook">Opening line</Label>
            <button
              type="button"
              className="inline-flex min-h-11 items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
              onClick={() => void onRewrite("hook")}
              disabled={rewriting !== null}
            >
              <RefreshCw className="size-3" /> Tighten
            </button>
          </div>
          <Input
            id="hook"
            className="mt-1.5"
            value={clip.hook}
            onChange={(e) => onChange({ ...clip, hook: e.target.value })}
          />
        </div>

        <div>
          <Label>Aspect</Label>
          <div className="mt-1.5 flex rounded-lg bg-secondary p-1">
            {ASPECTS.map((aspect) => (
              <button
                key={aspect}
                type="button"
                onClick={() => onChange({ ...clip, aspect })}
                className={`h-11 flex-1 rounded-md text-xs font-medium ${clip.aspect === aspect ? "bg-background shadow-[var(--shadow-border)]" : "text-muted-foreground"}`}
              >
                {aspect}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-2 flex justify-between text-xs text-muted-foreground">
            <Label>Reframe</Label>
            <span className="tabular-nums">{Math.round(clip.reframe * 100)}%</span>
          </div>
          <Slider
            min={0}
            max={1}
            step={0.01}
            value={[clip.reframe]}
            onValueChange={([reframe]) => onChange({ ...clip, reframe: reframe ?? 0.5 })}
          />
        </div>

        <div>
          <div className="mb-2 flex justify-between text-xs text-muted-foreground">
            <Label>Trim</Label>
            <span className="tabular-nums">
              {formatClock(clip.start)} – {formatClock(clip.end)}
            </span>
          </div>
          <Slider
            min={0}
            max={Math.max(project.duration, clip.end)}
            step={0.1}
            value={[clip.start, clip.end]}
            onValueChange={([start, end]) => {
              if (start == null || end == null || end - start < 3) return;
              onChange({ ...clip, start, end });
            }}
          />
        </div>

        <div className="rounded-lg bg-secondary px-4 py-3">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Why this cut</p>
          <p className="mt-2 text-sm leading-relaxed">{clip.reason}</p>
          <p className="mt-3 font-mono text-xs tabular-nums text-muted-foreground">
            Hook {clip.score}
          </p>
        </div>

        <div className="rounded-lg bg-secondary px-4 py-3">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Spoken text</p>
          <p className="mt-2 max-h-40 overflow-auto text-sm leading-relaxed text-muted-foreground">
            {clipText || "No speech in this window."}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() =>
              void copy(
                `${formatClock(clip.start)} – ${formatClock(clip.end)}`,
                "In/out copied",
              )
            }
          >
            <Copy className="size-3.5" />
            Copy in/out
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => void copy(clip.hook, "Hook copied")}
          >
            <Copy className="size-3.5" />
            Copy hook
          </Button>
          {project.youtubeId ? (
            <Button variant="secondary" size="sm" asChild>
              <a href={youtubeWatch(project.youtubeId, clip.start)} target="_blank" rel="noreferrer">
                <Link2 className="size-3.5" />
                Open at hook
              </a>
            </Button>
          ) : null}
        </div>

        {!src ? (
          <div className="rounded-lg bg-secondary px-4 py-4">
            <p className="text-sm leading-relaxed text-muted-foreground">
              Preview plays on YouTube. Attach the source file to export a clean 9:16 cut with nothing on the picture.
            </p>
            <input
              ref={fileRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) onAttach?.(file);
              }}
            />
            <Button
              variant="outline"
              className="mt-3 w-full"
              onClick={() => fileRef.current?.click()}
            >
              <Upload className="size-4" />
              Attach source video
            </Button>
          </div>
        ) : null}

        <Button className="w-full" size="lg" onClick={() => void onExport()} disabled={exporting}>
          <Download className="size-4" />
          {exporting ? `Exporting ${Math.round(progress)}%` : "Download clean cut"}
        </Button>
      </div>
    </div>
  );
}
