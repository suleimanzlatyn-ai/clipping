import { Progress } from "@/components/ui/progress";
import type { Project } from "@/lib/clip/types";

const STEPS = [
  "Reading the source",
  "Transcribing speech",
  "Hunting the hook",
  "Scoring moments",
  "Cutting clean",
];

export function ProcessingView({ project }: { project: Project }) {
  return (
    <div className="mx-auto flex min-h-[70dvh] max-w-lg flex-col justify-center px-4">
      <p className="text-xs font-medium tracking-[0.2em] text-muted-foreground uppercase">Working</p>
      <h1 className="font-display mt-3 text-4xl tracking-tight">{project.name}</h1>
      <p className="mt-3 text-sm text-muted-foreground">{project.progressLabel}</p>
      <Progress className="mt-8" value={project.progress} />
      <ol className="mt-8 space-y-2">
        {STEPS.map((step, i) => {
          const active = project.progressLabel === step || project.progress >= (i + 1) * 20;
          return (
            <li
              key={step}
              className={`text-sm ${active ? "text-foreground" : "text-muted-foreground/60"}`}
            >
              {String(i + 1).padStart(2, "0")}  {step}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
