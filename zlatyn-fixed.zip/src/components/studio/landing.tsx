import { useNavigate } from "@tanstack/react-router";
import { Clapperboard, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { readVideoDuration } from "@/lib/clip/audio";
import { listProjects, saveProject } from "@/lib/clip/idb";
import { createUploadProject, createYoutubeProject } from "@/lib/clip/pipeline";
import { createSampleProject } from "@/lib/clip/sample";
import type { ClipSettings, LengthPreset, ProjectSummary } from "@/lib/clip/types";
import { fetchYoutubeSource, parseYoutubeId } from "@/lib/clip/youtube";
import { formatClock } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SiteHeader } from "./site-header";

const LENGTHS: { id: LengthPreset; label: string }[] = [
  { id: "auto", label: "Auto" },
  { id: "short", label: "15s" },
  { id: "mid", label: "30s" },
  { id: "long", label: "60s" },
];

export function Landing() {
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState("");
  const [source, setSource] = useState<File | null>(null);
  const sourceRef = useRef<HTMLInputElement>(null);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [settings, setSettings] = useState<ClipSettings>({
    length: "auto",
    aspect: "9:16",
    prompt: "",
    removeFillers: true,
  });

  useEffect(() => {
    void listProjects().then(setProjects).catch(() => setProjects([]));
  }, []);

  async function onFile(file: File | undefined) {
    if (!file || busy) return;
    if (!file.type.startsWith("video/") && !file.type.startsWith("audio/")) {
      toast.error("Drop a video or audio file");
      return;
    }
    setBusy(true);
    try {
      const project = await createUploadProject(file, settings);
      await navigate({ to: "/studio/$id", params: { id: project.id } });
    } catch {
      toast.error("Could not open that file");
    } finally {
      setBusy(false);
    }
  }

  async function onUrl() {
    if (busy) return;
    const id = parseYoutubeId(url);
    if (!id) {
      toast.error("Paste a YouTube link");
      return;
    }
    setBusy(true);
    try {
      const yt = await fetchYoutubeSource({ data: { url } });
      if (!yt.ok) {
        toast.error(yt.error);
        return;
      }
      if (source) {
        const len = await readVideoDuration(source).catch(() => 0);
        if (len && yt.duration && Math.abs(len - yt.duration) > Math.max(5, yt.duration * 0.03)) {
          toast.warning("That file's length differs from the YouTube video. Clips may not line up.");
        }
      }
      const project = await createYoutubeProject(yt, settings, source);
      await navigate({ to: "/studio/$id", params: { id: project.id } });
    } catch {
      toast.error("Could not read that video");
    } finally {
      setBusy(false);
    }
  }

  async function onSample() {
    setBusy(true);
    try {
      const project = createSampleProject();
      await saveProject(project);
      await navigate({ to: "/studio/$id", params: { id: project.id } });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative min-h-dvh overflow-x-hidden">
      <div className="pointer-events-none absolute inset-0 hero-glow" />
      <SiteHeader />

      <main className="relative mx-auto max-w-2xl px-4 pb-16 pt-6 sm:px-8 sm:pt-12">
        <p className="mb-3 text-xs font-medium tracking-[0.22em] text-muted-foreground uppercase">
          Personal clip desk
        </p>
        <h1 className="font-display text-4xl leading-[1.05] tracking-tight text-paper sm:text-6xl">
          God clips. Human cuts.
        </h1>
        <p className="mt-4 max-w-md text-base leading-relaxed text-muted-foreground">
          Paste a YouTube link or drop the file. Zlatyn hunts the spoken hook, cuts a complete thought, and leaves the picture clean — no captions, no watermark.
        </p>

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDrag(false);
            void onFile(e.dataTransfer.files[0]);
          }}
          className={`mt-8 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] ${drag ? "shadow-[var(--shadow-border-hover)]" : ""}`}
        >
          <Label htmlFor="yt">YouTube URL</Label>
          <div className="mt-1.5 flex flex-col gap-2 sm:flex-row">
            <Input
              id="yt"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void onUrl();
              }}
              placeholder="https://youtube.com/watch?v=…"
            />
            <Button disabled={busy} onClick={() => void onUrl()} className="sm:w-40">
              Get clips
            </Button>
          </div>

          <input
            ref={sourceRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => setSource(e.target.files?.[0] ?? null)}
          />
          <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
            <button
              type="button"
              className="min-h-11 font-medium underline-offset-2 hover:text-foreground hover:underline"
              onClick={() => sourceRef.current?.click()}
            >
              {source ? "Change video file" : "Add the video file for preview and export (optional)"}
            </button>
            {source ? (
              <>
                <span className="min-w-0 truncate">{source.name}</span>
                <button type="button" className="min-h-11 px-2 hover:text-foreground" onClick={() => setSource(null)}>
                  Remove
                </button>
              </>
            ) : null}
          </div>

          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-border px-4 py-5 text-sm text-muted-foreground transition-colors duration-150 hover:bg-secondary hover:text-foreground"
          >
            <Upload className="size-4" />
            Or drop a video file
          </button>
          <input
            ref={inputRef}
            type="file"
            accept="video/*,audio/*"
            className="hidden"
            onChange={(e) => void onFile(e.target.files?.[0])}
          />

          <div className="mt-4">
            <Label>Clip length</Label>
            <div className="mt-1.5 flex rounded-lg bg-secondary p-1">
              {LENGTHS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSettings((s) => ({ ...s, length: item.id }))}
                  className={`h-11 flex-1 rounded-md text-xs font-medium transition-colors duration-150 ${settings.length === item.id ? "bg-background text-foreground shadow-[var(--shadow-border)]" : "text-muted-foreground"}`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <Label htmlFor="brief">Campaign brief (optional)</Label>
            <Textarea
              id="brief"
              className="mt-1.5 min-h-20"
              placeholder="Whop campaign rules: who the talent is, what cannot appear, platforms, banned claims…"
              value={settings.prompt}
              onChange={(e) => setSettings((s) => ({ ...s, prompt: e.target.value }))}
            />
          </div>

          <button
            type="button"
            className="mt-4 min-h-11 text-xs font-medium text-muted-foreground hover:text-foreground"
            disabled={busy}
            onClick={() => void onSample()}
          >
            Try a sample interview
          </button>
        </div>
      </main>

      {projects.length ? (
        <section className="mx-auto max-w-2xl px-4 pb-24 sm:px-8">
          <h2 className="font-display text-2xl tracking-tight">Recent</h2>
          <ul className="mt-5 grid gap-3">
            {projects.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => navigate({ to: "/studio/$id", params: { id: p.id } })}
                  className="flex w-full items-center gap-3 rounded-xl bg-card p-3 text-left shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
                >
                  <span className="grid size-14 shrink-0 place-items-center overflow-hidden rounded-md bg-elevated">
                    {p.thumbnail ? (
                      <img src={p.thumbnail} alt="" className="size-full object-cover" />
                    ) : (
                      <Clapperboard className="size-4 text-muted-foreground" />
                    )}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium">{p.name}</span>
                    <span className="mt-0.5 block text-xs text-muted-foreground">
                      {p.clipCount} clips · {formatClock(p.duration)}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
