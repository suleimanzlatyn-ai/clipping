import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function SiteHeader({
  right,
  className,
}: {
  right?: ReactNode;
  className?: string;
}) {
  return (
    <header
      className={cn(
        "flex items-center justify-between gap-4 px-4 py-4 sm:px-8",
        className,
      )}
    >
      <Link to="/" className="flex items-center gap-2.5 text-foreground">
        <span className="grid size-8 place-items-center rounded-sm bg-paper font-display text-sm tracking-tight text-ink">
          Z
        </span>
        <span className="font-display text-lg tracking-tight">ZLATYN</span>
      </Link>
      {right ? <div className="flex items-center gap-2">{right}</div> : null}
    </header>
  );
}
